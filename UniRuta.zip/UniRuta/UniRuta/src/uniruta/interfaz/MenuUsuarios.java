package uniruta.interfaz;

import java.time.LocalTime;
import uniruta.modelo.Usuario;
import uniruta.negocio.CatalogoSectores;
import uniruta.negocio.GestorUsuarios;
import uniruta.negocio.ReglaNegocioException;
import uniruta.negocio.ValidadorHorario;
public class MenuUsuarios {
    private final EntradaConsola in;
    private final GestorUsuarios gestor;
    private final ValidadorHorario validador;
    private final CatalogoSectores catalogo;

    public MenuUsuarios(EntradaConsola in, GestorUsuarios gestor, ValidadorHorario validador, CatalogoSectores catalogo) {
        this.in = in;
        this.gestor = gestor;
        this.validador = validador;
        this.catalogo = catalogo;
    }

    public void mostrar() {
        int op;
        do {
            System.out.println("\n--- MÓDULO 1: USUARIOS Y PERFILES ---");
            System.out.println("1. Registrar usuario (RF01)");
            System.out.println("2. Listar usuarios");
            System.out.println("3. Buscar usuario por ID");
            System.out.println("4. Actualizar usuario");
            System.out.println("5. Eliminar usuario");
            System.out.println("6. Validar disponibilidad horaria (RF02)");
            System.out.println("0. Volver");
            op = in.leerEntero("Opción: ", 0, 6);
            try {
                switch (op) {
                    case 1: registrar(); break;
                    case 2: listar(); break;
                    case 3: buscar(); break;
                    case 4: actualizar(); break;
                    case 5: eliminar(); break;
                    case 6: validarHorario(); break;
                    default: break;
                }
            } catch (ReglaNegocioException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (op != 0);
    }

    /** Pide un sector; con '?' muestra la lista disponible. */
    String pedirSector(String mensaje) {
        return in.leerValidado(mensaje + " (escriba ? para ver la lista): ", s -> {
            if (s.equals("?")) {
                MenuRutas.imprimirSectores(catalogo);
                throw new ReglaNegocioException("Escriba el nombre de uno de los sectores listados.");
            }
            gestor.validarSector(s);
            return catalogo.nombreOficial(s);
        });
    }

    private void registrar() throws ReglaNegocioException {
        System.out.println("\nRegistro de usuario");
        String nombre = in.leerValidado("Nombre completo: ", s -> { gestor.validarNombre(s); return s; });
        String correo = in.leerValidado("Correo institucional: ", gestor::validarCorreoNuevo);
        String sector = pedirSector("Sector de residencia");
        int rol = in.leerEntero("Rol (1 = Conductor, 2 = Pasajero): ", 1, 2);
        LocalTime hora = in.leerHora("Hora habitual de entrada a clases (HH:mm): ");
        Usuario u = gestor.registrar(nombre, correo, sector, rol == 1 ? "Conductor" : "Pasajero", hora);
        System.out.println("[OK] Usuario registrado con ID " + u.getId() + ".");
    }

    private void listar() {
        if (gestor.listar().isEmpty()) {
            System.out.println("No hay usuarios registrados.");
            return;
        }
        System.out.println();
        for (Usuario u : gestor.listar()) System.out.println(u);
    }

    private void buscar() {
        Usuario u = gestor.buscarPorId(in.leerEntero("ID del usuario: ", 1, Integer.MAX_VALUE));
        System.out.println(u == null ? "No existe un usuario con ese ID." : u.toString());
    }

    private void actualizar() throws ReglaNegocioException {
        int id = in.leerEntero("ID del usuario a actualizar: ", 1, Integer.MAX_VALUE);
        Usuario u = gestor.buscarPorId(id);
        if (u == null) throw new ReglaNegocioException("No existe un usuario con ID " + id + ".");
        System.out.println("Actual: " + u);
        String nombre = in.leerValidado("Nuevo nombre: ", s -> { gestor.validarNombre(s); return s; });
        String sector = pedirSector("Nuevo sector");
        LocalTime hora = in.leerHora("Nueva hora de clases (HH:mm): ");
        gestor.actualizar(id, nombre, sector, hora);
        System.out.println("[OK] Usuario actualizado.");
    }

    private void eliminar() throws ReglaNegocioException {
        int id = in.leerEntero("ID del usuario a eliminar: ", 1, Integer.MAX_VALUE);
        if (in.confirmar("¿Seguro que desea eliminarlo?")) {
            gestor.eliminar(id);
            System.out.println("[OK] Usuario eliminado.");
        }
    }

    private void validarHorario() throws ReglaNegocioException {
        LocalTime salida = in.leerHora("Hora de salida del conductor (HH:mm): ");
        LocalTime entrada = in.leerHora("Hora de entrada a clases del pasajero (HH:mm): ");
        validador.validar(salida, entrada);
        System.out.println("[OK] Horarios compatibles (la salida es como máximo "
                + ValidadorHorario.TOLERANCIA_MINUTOS + " minutos antes de la entrada).");
    }
}
