package uniruta.interfaz;

import uniruta.modelo.Conductor;
import uniruta.modelo.Emparejamiento;
import uniruta.modelo.EstadoEmparejamiento;
import uniruta.modelo.Ruta;
import uniruta.modelo.Vehiculo;
import uniruta.negocio.ControlCupos;
import uniruta.negocio.GestorRutas;
import uniruta.negocio.GestorUsuarios;
import uniruta.negocio.GestorVehiculos;
import uniruta.negocio.ReglaNegocioException;

public class MenuVehiculos {
    private final EntradaConsola in;
    private final GestorUsuarios usuarios;
    private final GestorVehiculos vehiculos;
    private final GestorRutas rutas;
    private final ControlCupos cupos;

    public MenuVehiculos(EntradaConsola in, GestorUsuarios usuarios, GestorVehiculos vehiculos,
                         GestorRutas rutas, ControlCupos cupos) {
        this.in = in;
        this.usuarios = usuarios;
        this.vehiculos = vehiculos;
        this.rutas = rutas;
        this.cupos = cupos;
    }

    public void mostrar() {
        int op;
        do {
            System.out.println("\n--- MÓDULO 2: VEHÍCULOS Y CAPACIDAD ---");
            System.out.println("1. Registrar vehículo (RF03)");
            System.out.println("2. Listar vehículos");
            System.out.println("3. Actualizar puestos y rendimiento");
            System.out.println("4. Eliminar vehículo");
            System.out.println("5. Verificar cupos de una ruta (RF04)");
            System.out.println("0. Volver");
            op = in.leerEntero("Opción: ", 0, 5);
            try {
                switch (op) {
                    case 1: registrar(); break;
                    case 2: listar(); break;
                    case 3: actualizar(); break;
                    case 4: eliminar(); break;
                    case 5: verificarCupos(); break;
                    default: break;
                }
            } catch (ReglaNegocioException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (op != 0);
    }

    private void registrar() throws ReglaNegocioException {
        Conductor c = usuarios.obtenerConductor(in.leerEntero("ID del conductor: ", 1, Integer.MAX_VALUE));
        if (c.getVehiculo() != null) throw new ReglaNegocioException("El conductor ya tiene un vehículo registrado.");
        String placa = in.leerValidado("Placa (ejemplo ABC-1234): ", vehiculos::validarPlaca);
        String modelo = in.leerTexto("Modelo: ");
        int puestos = in.leerEntero("Número de puestos para pasajeros (1-8): ", 1, 8);
        double rend = in.leerDecimal("Rendimiento (km por galón): ", 0.1, 200);
        Vehiculo v = vehiculos.registrar(c, placa, modelo, puestos, rend);
        System.out.println("[OK] Vehículo " + v.getPlaca() + " asociado a " + c.getNombre() + ".");
    }

    private void listar() {
        if (vehiculos.listar().isEmpty()) {
            System.out.println("No hay vehículos registrados.");
            return;
        }
        for (Vehiculo v : vehiculos.listar()) {
            System.out.println(v + " | conductor: " + vehiculos.duenoDe(v.getPlaca()).getNombre());
        }
    }

    private void actualizar() throws ReglaNegocioException {
        String placa = in.leerTexto("Placa del vehículo: ");
        if (vehiculos.buscarPorPlaca(placa) == null) {
            throw new ReglaNegocioException("No existe un vehículo con placa " + placa + ".");
        }
        int puestos = in.leerEntero("Nuevos puestos (1-8): ", 1, 8);
        double rend = in.leerDecimal("Nuevo rendimiento (km por galón): ", 0.1, 200);
        vehiculos.actualizar(placa, puestos, rend);
        System.out.println("[OK] Vehículo actualizado.");
    }

    private void eliminar() throws ReglaNegocioException {
        String placa = in.leerTexto("Placa del vehículo a eliminar: ");
        if (in.confirmar("¿Seguro que desea eliminarlo?")) {
            vehiculos.eliminar(placa);
            System.out.println("[OK] Vehículo eliminado.");
        }
    }

    private void verificarCupos() throws ReglaNegocioException {
        Ruta r = rutas.buscar(in.leerTexto("ID de la ruta (ejemplo R001): "));
        if (r == null) throw new ReglaNegocioException("No existe esa ruta.");
        System.out.println(r);
        System.out.println("Estado de cupos: " + cupos.estado(r));
        for (Emparejamiento e : r.getEmparejamientos()) {
            if (e.getEstado() == EstadoEmparejamiento.ACEPTADO) {
                System.out.println("  - " + e.getPasajero().getNombre() + " (" + e.getPasajero().getSector() + ")");
            }
        }
        try {
            cupos.verificarCupo(r);
            System.out.println("[OK] La ruta aún admite pasajeros.");
        } catch (ReglaNegocioException e) {
            System.out.println("Aviso: " + e.getMessage());
        }
    }
}
