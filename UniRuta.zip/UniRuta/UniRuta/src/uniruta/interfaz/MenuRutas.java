package uniruta.interfaz;

import java.time.LocalTime;
import java.util.List;
import uniruta.modelo.Conductor;
import uniruta.modelo.Emparejamiento;
import uniruta.modelo.Pasajero;
import uniruta.modelo.Ruta;
import uniruta.negocio.CalculadorCostos;
import uniruta.negocio.CatalogoSectores;
import uniruta.negocio.GestorRutas;
import uniruta.negocio.GestorUsuarios;
import uniruta.negocio.MotorEmparejamiento;
import uniruta.negocio.ReglaNegocioException;

public class MenuRutas {
    private final EntradaConsola in;
    private final GestorUsuarios usuarios;
    private final GestorRutas rutas;
    private final MotorEmparejamiento motor;
    private final CalculadorCostos calculador;
    private final CatalogoSectores catalogo;

    public MenuRutas(EntradaConsola in, GestorUsuarios usuarios, GestorRutas rutas, MotorEmparejamiento motor,
                     CalculadorCostos calculador, CatalogoSectores catalogo) {
        this.in = in;
        this.usuarios = usuarios;
        this.rutas = rutas;
        this.motor = motor;
        this.calculador = calculador;
        this.catalogo = catalogo;
    }

    static void imprimirSectores(CatalogoSectores catalogo) {
        System.out.println("Sectores disponibles:");
        for (String s : catalogo.listarSectores()) System.out.println("  - " + s);
    }

    public void mostrar() {
        int op;
        do {
            System.out.println("\n--- MÓDULO 3: RUTAS Y MATCHMAKING ---");
            System.out.println("1. Registrar ruta (RF05)");
            System.out.println("2. Listar rutas");
            System.out.println("3. Eliminar ruta");
            System.out.println("4. Ver sectores disponibles");
            System.out.println("5. Buscar rutas compatibles para un pasajero");
            System.out.println("6. Emparejar pasajero con ruta (RF06)");
            System.out.println("7. Ver pasajeros de una ruta");
            System.out.println("0. Volver");
            op = in.leerEntero("Opción: ", 0, 7);
            try {
                switch (op) {
                    case 1: registrar(); break;
                    case 2: listar(); break;
                    case 3: eliminar(); break;
                    case 4: imprimirSectores(catalogo); break;
                    case 5: buscarCompatibles(); break;
                    case 6: emparejar(); break;
                    case 7: verPasajeros(); break;
                    default: break;
                }
            } catch (ReglaNegocioException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (op != 0);
    }

    private void registrar() throws ReglaNegocioException {
        Conductor c = usuarios.obtenerConductor(in.leerEntero("ID del conductor: ", 1, Integer.MAX_VALUE));
        if (c.getVehiculo() == null) {
            throw new ReglaNegocioException("El conductor debe registrar un vehículo antes de publicar rutas.");
        }
        String origen = in.leerValidado("Sector de origen (? para ver la lista): ", s -> {
            if (s.equals("?")) {
                imprimirSectores(catalogo);
                throw new ReglaNegocioException("Escriba el nombre de uno de los sectores listados.");
            }
            if (!catalogo.existe(s)) throw new ReglaNegocioException("El sector '" + s + "' no existe en el catálogo.");
            if (catalogo.esCampus(s)) throw new ReglaNegocioException("El origen no puede ser el campus universitario.");
            return s;
        });
        String destino = in.leerLinea("Destino [Enter = " + CatalogoSectores.CAMPUS + "]: ");
        if (destino.isEmpty()) destino = CatalogoSectores.CAMPUS;
        LocalTime hora = in.leerHora("Hora de salida (HH:mm): ");
        System.out.printf("Distancia sugerida en línea recta: %.1f km%n",
                catalogo.existe(destino) ? catalogo.distancia(origen, destino) : 0.0);
        double dist = in.leerDecimal("Distancia estimada del viaje (km): ", 0.1, 100);
        Ruta r = rutas.registrar(c, origen, destino, hora, dist);
        System.out.println("[OK] Ruta registrada: " + r);
    }

    private void listar() {
        if (rutas.listar().isEmpty()) {
            System.out.println("No hay rutas registradas.");
            return;
        }
        for (Ruta r : rutas.listar()) System.out.println(r);
    }

    private void eliminar() throws ReglaNegocioException {
        String id = in.leerTexto("ID de la ruta a eliminar: ");
        if (in.confirmar("¿Seguro que desea eliminarla?")) {
            rutas.eliminar(id);
            System.out.println("[OK] Ruta eliminada.");
        }
    }

    private void buscarCompatibles() throws ReglaNegocioException {
        Pasajero p = usuarios.obtenerPasajero(in.leerEntero("ID del pasajero: ", 1, Integer.MAX_VALUE));
        System.out.println("Pasajero: " + p.getNombre() + " | " + p.getSector() + " | clases " + p.getHoraClases());
        List<Ruta> compatibles = motor.buscarCompatibles(p, rutas.listar());
        if (compatibles.isEmpty()) {
            System.out.println("No hay rutas compatibles. Motivos por ruta:");
            for (Ruta r : rutas.listar()) System.out.println("  " + r.getId() + ": " + motor.evaluar(p, r));
            return;
        }
        System.out.println("Rutas compatibles:");
        for (Ruta r : compatibles) {
            System.out.printf("  %s | desvío %.1f km%n", r, motor.calcularDesvio(p, r));
        }
    }

    private void emparejar() throws ReglaNegocioException {
        Pasajero p = usuarios.obtenerPasajero(in.leerEntero("ID del pasajero: ", 1, Integer.MAX_VALUE));
        Ruta r = rutas.buscar(in.leerTexto("ID de la ruta: "));
        if (r == null) throw new ReglaNegocioException("No existe esa ruta.");
        Emparejamiento e = motor.emparejar(p, r);
        calculador.actualizarCuotas(r);
        System.out.println("[OK] Emparejamiento aceptado: " + e);
    }

    private void verPasajeros() throws ReglaNegocioException {
        Ruta r = rutas.buscar(in.leerTexto("ID de la ruta: "));
        if (r == null) throw new ReglaNegocioException("No existe esa ruta.");
        System.out.println(r);
        if (r.getEmparejamientos().isEmpty()) System.out.println("Sin pasajeros.");
        for (Emparejamiento e : r.getEmparejamientos()) System.out.println("  " + e);
    }
}
