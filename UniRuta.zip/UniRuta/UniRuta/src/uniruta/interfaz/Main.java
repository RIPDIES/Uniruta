package uniruta.interfaz;

public class Main {
    public static void main(String[] args) {
        try {
            new MenuPrincipal().iniciar();
        } catch (EntradaConsola.FinEntrada e) {
            System.out.println("\nEntrada finalizada. Hasta pronto.");
        }
    }
}
