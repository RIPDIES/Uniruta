package uniruta.interfaz;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
import uniruta.negocio.ReglaNegocioException;

public class EntradaConsola {
    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter FORMATO_MES = DateTimeFormatter.ofPattern("MM/yyyy");

    public static class FinEntrada extends RuntimeException {
        private static final long serialVersionUID = 1L;
    }

    public interface Validador<T> {
        T aplicar(String texto) throws ReglaNegocioException;
    }

    private final Scanner scanner = new Scanner(System.in);

    public String leerLinea(String mensaje) {
        System.out.print(mensaje);
        if (!scanner.hasNextLine()) throw new FinEntrada();
        return scanner.nextLine().trim();
    }
    public String leerTexto(String mensaje) {
        while (true) {
            String s = leerLinea(mensaje);
            if (!s.isEmpty()) return s;
            System.out.println("Error: este campo es obligatorio.");
        }
    }
    public <T> T leerValidado(String mensaje, Validador<T> validador) {
        while (true) {
            String s = leerLinea(mensaje);
            try {
                return validador.aplicar(s);
            } catch (ReglaNegocioException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    public int leerEntero(String mensaje, int min, int max) {
        while (true) {
            String s = leerLinea(mensaje);
            try {
                int n = Integer.parseInt(s);
                if (n >= min && n <= max) return n;
                System.out.println("Error: ingrese un número entre " + min + " y " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Error: ingrese un número entero válido.");
            }
        }
    }

    public double leerDecimal(String mensaje, double min, double max) {
        while (true) {
            String s = leerLinea(mensaje).replace(',', '.');
            try {
                double d = Double.parseDouble(s);
                if (!Double.isNaN(d) && !Double.isInfinite(d) && d >= min && d <= max) return d;
                System.out.println("Error: ingrese un valor entre " + min + " y " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Error: ingrese un número válido (ejemplo: 12.5).");
            }
        }
    }

    public LocalTime leerHora(String mensaje) {
        while (true) {
            String s = leerLinea(mensaje);
            try {
                return LocalTime.parse(s.length() == 4 ? "0" + s : s);
            } catch (DateTimeParseException e) {
                System.out.println("Error: use el formato HH:mm de 24 horas (ejemplo: 07:30).");
            }
        }
    }
    public LocalDate leerFecha(String mensaje) {
        while (true) {
            String s = leerLinea(mensaje);
            if (s.isEmpty()) return LocalDate.now();
            try {
                return LocalDate.parse(s, FORMATO_FECHA);
            } catch (DateTimeParseException e) {
                System.out.println("Error: use el formato dd/MM/aaaa (ejemplo: 21/11/2026).");
            }
        }
    }
    public YearMonth leerMes(String mensaje) {
        while (true) {
            String s = leerLinea(mensaje);
            if (s.isEmpty()) return YearMonth.now();
            try {
                return YearMonth.parse(s, FORMATO_MES);
            } catch (DateTimeParseException e) {
                System.out.println("Error: use el formato MM/aaaa (ejemplo: 11/2026).");
            }
        }
    }

    public boolean confirmar(String mensaje) {
        while (true) {
            String s = leerLinea(mensaje + " (s/n): ").toLowerCase();
            if (s.equals("s") || s.equals("si") || s.equals("sí")) return true;
            if (s.equals("n") || s.equals("no")) return false;
            System.out.println("Error: responda s o n.");
        }
    }
}
