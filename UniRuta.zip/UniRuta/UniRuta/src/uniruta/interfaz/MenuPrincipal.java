package uniruta.interfaz;

import java.time.LocalTime;
import uniruta.modelo.Conductor;
import uniruta.negocio.CalculadorCostos;
import uniruta.negocio.CatalogoSectores;
import uniruta.negocio.ControlCupos;
import uniruta.negocio.GestorCombustible;
import uniruta.negocio.GestorRutas;
import uniruta.negocio.GestorUsuarios;
import uniruta.negocio.GestorVehiculos;
import uniruta.negocio.MotorEmparejamiento;
import uniruta.negocio.ReglaNegocioException;
import uniruta.negocio.ValidadorHorario;

public class MenuPrincipal {
    private final EntradaConsola in = new EntradaConsola();
    private final CatalogoSectores catalogo = new CatalogoSectores();
    private final GestorUsuarios usuarios = new GestorUsuarios(catalogo);
    private final ValidadorHorario validador = new ValidadorHorario();
    private final GestorVehiculos vehiculos = new GestorVehiculos();
    private final ControlCupos cupos = new ControlCupos();
    private final GestorRutas rutas = new GestorRutas(catalogo);
    private final MotorEmparejamiento motor = new MotorEmparejamiento(validador, cupos, catalogo);
    private final GestorCombustible combustibles = new GestorCombustible();
    private final CalculadorCostos calculador = new CalculadorCostos(combustibles);

    private final MenuUsuarios menuUsuarios = new MenuUsuarios(in, usuarios, validador, catalogo);
    private final MenuVehiculos menuVehiculos = new MenuVehiculos(in, usuarios, vehiculos, rutas, cupos);
    private final MenuRutas menuRutas = new MenuRutas(in, usuarios, rutas, motor, calculador, catalogo);
    private final MenuCostos menuCostos = new MenuCostos(in, combustibles, calculador, rutas);

    public void iniciar() {
        System.out.println("=====================================================");
        System.out.println("   UniRuta - Carpooling Universitario (modo consola)");
        System.out.println("=====================================================");
        int op;
        do {
            System.out.println("\n--- MENÚ PRINCIPAL ---");
            System.out.println("1. Usuarios y perfiles (Módulo 1)");
            System.out.println("2. Vehículos y capacidad (Módulo 2)");
            System.out.println("3. Rutas y matchmaking (Módulo 3)");
            System.out.println("4. Costos compartidos (Módulo 4)");
            System.out.println("5. Cargar datos de ejemplo");
            System.out.println("0. Salir");
            op = in.leerEntero("Opción: ", 0, 5);
            switch (op) {
                case 1: menuUsuarios.mostrar(); break;
                case 2: menuVehiculos.mostrar(); break;
                case 3: menuRutas.mostrar(); break;
                case 4: menuCostos.mostrar(); break;
                case 5: cargarEjemplo(); break;
                default: break;
            }
        } while (op != 0);
        System.out.println("Gracias por usar UniRuta. ¡Hasta pronto!");
    }
    private void cargarEjemplo() {
        if (!usuarios.listar().isEmpty()) {
            System.out.println("Ya hay datos registrados; los datos de ejemplo solo se cargan con el sistema vacío.");
            return;
        }
        try {
            Conductor carlos = (Conductor) usuarios.registrar("Carlos Mena", "carlos.mena@udla.edu.ec",
                    "Cumbayá", "Conductor", LocalTime.of(8, 0));
            Conductor lucia = (Conductor) usuarios.registrar("Lucía Paredes", "lucia.paredes@udla.edu.ec",
                    "Carcelén", "Conductor", LocalTime.of(8, 0));
            usuarios.registrar("Ana Torres", "ana.torres@udla.edu.ec", "La Carolina", "Pasajero", LocalTime.of(8, 0));
            usuarios.registrar("Pedro Vega", "pedro.vega@udla.edu.ec", "Cumbayá", "Pasajero", LocalTime.of(7, 30));
            usuarios.registrar("Sofía Ramos", "sofia.ramos@udla.edu.ec", "Quitumbe", "Pasajero", LocalTime.of(8, 0));
            usuarios.registrar("Mateo Cruz", "mateo.cruz@udla.edu.ec", "La Floresta", "Pasajero", LocalTime.of(7, 30));
            vehiculos.registrar(carlos, "PBA-1234", "Chevrolet Sail", 3, 35.0);
            vehiculos.registrar(lucia, "PCD-5678", "Kia Rio", 2, 35.0);
            rutas.registrar(carlos, "Cumbayá", CatalogoSectores.CAMPUS, LocalTime.of(6, 45), 14.0);
            rutas.registrar(lucia, "Carcelén", CatalogoSectores.CAMPUS, LocalTime.of(7, 15), 14.0);
            combustibles.registrar("Extra", 2.76);
            System.out.println("[OK] Datos de ejemplo cargados: 2 conductores (IDs 1-2), 4 pasajeros (IDs 3-6),");
            System.out.println("     2 vehículos, 2 rutas (R001 y R002) y combustible Extra a $2.76 por galón.");
        } catch (ReglaNegocioException e) {
            System.out.println("Error al cargar los datos de ejemplo: " + e.getMessage());
        }
    }
}
