package uniruta.interfaz;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import java.util.Map;
import uniruta.modelo.Combustible;
import uniruta.modelo.Emparejamiento;
import uniruta.modelo.EstadoEmparejamiento;
import uniruta.modelo.Pasajero;
import uniruta.modelo.Ruta;
import uniruta.negocio.CalculadorCostos;
import uniruta.negocio.GestorCombustible;
import uniruta.negocio.GestorRutas;
import uniruta.negocio.ReglaNegocioException;

public class MenuCostos {
    private final EntradaConsola in;
    private final GestorCombustible combustibles;
    private final CalculadorCostos calculador;
    private final GestorRutas rutas;

    public MenuCostos(EntradaConsola in, GestorCombustible combustibles, CalculadorCostos calculador, GestorRutas rutas) {
        this.in = in;
        this.combustibles = combustibles;
        this.calculador = calculador;
        this.rutas = rutas;
    }

    public void mostrar() {
        int op;
        do {
            System.out.println("\n--- MÓDULO 4: COSTOS COMPARTIDOS ---");
            System.out.println("1. Registrar precio del combustible (RF07)");
            System.out.println("2. Ver combustibles y elegir el vigente");
            System.out.println("3. Calcular cuota con datos manuales (RF08)");
            System.out.println("4. Calcular cuota de una ruta (RF08)");
            System.out.println("5. Registrar viaje realizado");
            System.out.println("6. Reporte mensual de ahorro");
            System.out.println("0. Volver");
            op = in.leerEntero("Opción: ", 0, 6);
            try {
                switch (op) {
                    case 1: registrarPrecio(); break;
                    case 2: verCombustibles(); break;
                    case 3: cuotaManual(); break;
                    case 4: cuotaRuta(); break;
                    case 5: registrarViaje(); break;
                    case 6: reporte(); break;
                    default: break;
                }
            } catch (ReglaNegocioException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (op != 0);
    }

    private void registrarPrecio() throws ReglaNegocioException {
        String tipo = in.leerTexto("Tipo de combustible (Extra, Súper, Diésel...): ");
        double precio = in.leerDecimal("Precio por galón en dólares: ", 0.01, 10);
        Combustible c = combustibles.registrar(tipo, precio);
        System.out.println("[OK] Tarifa vigente: " + c);
    }

    private void verCombustibles() throws ReglaNegocioException {
        List<Combustible> lista = combustibles.listar();
        if (lista.isEmpty()) {
            System.out.println("No hay combustibles registrados.");
            return;
        }
        for (Combustible c : lista) {
            System.out.println((c == combustibles.getVigente() ? "* " : "  ") + c);
        }
        System.out.println("(* = tarifa vigente)");
        String tipo = in.leerLinea("Escriba un tipo para hacerlo vigente [Enter = mantener]: ");
        if (!tipo.isEmpty()) {
            combustibles.seleccionarVigente(tipo);
            System.out.println("[OK] Tarifa vigente: " + combustibles.getVigente());
        }
    }

    private void cuotaManual() throws ReglaNegocioException {
        double dist = in.leerDecimal("Distancia del viaje (km): ", 0.1, 1000);
        double rend = in.leerDecimal("Rendimiento del vehículo (km por galón): ", 0.1, 200);
        double precio = in.leerDecimal("Precio del combustible ($ por galón): ", 0.01, 10);
        int pas = in.leerEntero("Número de pasajeros: ", 1, 20);
        double total = CalculadorCostos.costoTotal(dist, rend, precio);
        double cuota = calculador.calcularCuota(dist, rend, precio, pas);
        System.out.printf("Costo total del viaje: $%.2f%n", total);
        System.out.printf("Ocupantes (pasajeros + conductor): %d%n", pas + 1);
        System.out.printf("Cuota por pasajero: $%.2f%n", cuota);
    }

    private Ruta pedirRuta() throws ReglaNegocioException {
        Ruta r = rutas.buscar(in.leerTexto("ID de la ruta (ejemplo R001): "));
        if (r == null) throw new ReglaNegocioException("No existe esa ruta.");
        return r;
    }

    private void cuotaRuta() throws ReglaNegocioException {
        Ruta r = pedirRuta();
        double cuota = calculador.cuotaRuta(r);
        calculador.actualizarCuotas(r);
        System.out.println(r);
        System.out.printf("Costo total del viaje: $%.2f%n", calculador.costoTotalRuta(r));
        System.out.printf("Cuota por pasajero: $%.2f (%d pasajeros + conductor)%n", cuota, r.contarPasajeros());
        for (Emparejamiento e : r.getEmparejamientos()) {
            if (e.getEstado() == EstadoEmparejamiento.ACEPTADO) {
                System.out.printf("  - %s: $%.2f%n", e.getPasajero().getNombre(), e.getCuota());
            }
        }
    }

    private void registrarViaje() throws ReglaNegocioException {
        Ruta r = pedirRuta();
        LocalDate fecha = in.leerFecha("Fecha del viaje dd/MM/aaaa [Enter = hoy]: ");
        List<CalculadorCostos.Liquidacion> liq = calculador.registrarViaje(r, fecha);
        System.out.println("[OK] Viaje registrado. Liquidaciones:");
        for (CalculadorCostos.Liquidacion l : liq) {
            System.out.printf("  - %s paga $%.2f y ahorra $%.2f%n",
                    l.getPasajero().getNombre(), l.getCuota(), l.getAhorro());
        }
    }

    private static String formato(YearMonth mes) {
        return String.format("%02d/%d", mes.getMonthValue(), mes.getYear());
    }

    private void reporte() {
        YearMonth mes = in.leerMes("Mes MM/aaaa [Enter = mes actual]: ");
        Map<Pasajero, double[]> reporte = calculador.reporteMensual(mes);
        if (reporte.isEmpty()) {
            System.out.println("No hay viajes registrados en " + formato(mes) + ".");
            return;
        }
        System.out.println("\nReporte de ahorro de " + formato(mes));
        System.out.printf("%-25s %7s %12s %12s%n", "Pasajero", "Viajes", "Pagado ($)", "Ahorro ($)");
        double totalAhorro = 0;
        for (Map.Entry<Pasajero, double[]> e : reporte.entrySet()) {
            double[] f = e.getValue();
            System.out.printf("%-25s %7.0f %12.2f %12.2f%n", e.getKey().getNombre(), f[0], f[1], f[2]);
            totalAhorro += f[2];
        }
        System.out.printf("Ahorro total acumulado: $%.2f%n", totalAhorro);
    }
}
