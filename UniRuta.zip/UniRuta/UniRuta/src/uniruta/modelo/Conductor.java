package uniruta.modelo;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
public class Conductor extends Usuario {
    private Vehiculo vehiculo;
    private final List<Ruta> rutas = new ArrayList<>();

    public Conductor(int id, String nombre, String correo, String sector, LocalTime horaClases) {
        super(id, nombre, correo, sector, horaClases);
    }

    public void asignarVehiculo(Vehiculo v) { this.vehiculo = v; }
    public Vehiculo getVehiculo() { return vehiculo; }

    public void agregarRuta(Ruta r) { rutas.add(r); }
    public void quitarRuta(Ruta r) { rutas.remove(r); }
    public List<Ruta> getRutas() { return new ArrayList<>(rutas); }

    @Override
    public String getRol() { return "Conductor"; }
}
