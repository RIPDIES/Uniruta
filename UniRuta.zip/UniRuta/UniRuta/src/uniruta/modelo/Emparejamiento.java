package uniruta.modelo;
public class Emparejamiento {
    private final Pasajero pasajero;
    private final Ruta ruta;
    private double desvioKm;
    private double cuota;
    private EstadoEmparejamiento estado;
    public Emparejamiento(Pasajero pasajero, Ruta ruta, double desvioKm) {
        this.pasajero = pasajero;
        this.ruta = ruta;
        this.desvioKm = desvioKm;
        this.estado = EstadoEmparejamiento.PENDIENTE;
    }
    public void aceptar() { this.estado = EstadoEmparejamiento.ACEPTADO; }
    public void rechazar() { this.estado = EstadoEmparejamiento.RECHAZADO; }
    public Pasajero getPasajero() { return pasajero; }
    public Ruta getRuta() { return ruta; }
    public double getDesvioKm() { return desvioKm; }
    public void setDesvioKm(double desvioKm) { this.desvioKm = desvioKm; }
    public double getCuota() { return cuota; }
    public void setCuota(double cuota) { this.cuota = cuota; }
    public EstadoEmparejamiento getEstado() { return estado; }
    @Override
    public String toString() {
        return String.format("%s -> %s | desvío %.1f km | cuota $%.2f | %s",
                pasajero.getNombre(), ruta.getId(), desvioKm, cuota, estado);
    }
}
