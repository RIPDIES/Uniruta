package uniruta.modelo;
public class Combustible {
    private final String tipo;
    private double precioGalon;

    public Combustible(String tipo, double precioGalon) {
        this.tipo = tipo;
        this.precioGalon = precioGalon;
    }

    public boolean validarPrecio() { return precioGalon > 0 && precioGalon <= 10; }

    public String getTipo() { return tipo; }
    public double getPrecioGalon() { return precioGalon; }
    public void setPrecioGalon(double precioGalon) { this.precioGalon = precioGalon; }

    @Override
    public String toString() { return String.format("%s: $%.2f por galón", tipo, precioGalon); }
}
