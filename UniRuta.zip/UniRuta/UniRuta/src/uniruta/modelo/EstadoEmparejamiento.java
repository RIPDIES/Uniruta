package uniruta.modelo;

/** Estados posibles de un emparejamiento entre un pasajero y una ruta. */
public enum EstadoEmparejamiento {
    PENDIENTE,
    ACEPTADO,
    RECHAZADO
}
