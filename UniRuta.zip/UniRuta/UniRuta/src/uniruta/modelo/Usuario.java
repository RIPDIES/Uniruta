package uniruta.modelo;

import java.time.LocalTime;
public abstract class Usuario {
    private final int id;
    private String nombre;
    private String correo;
    private String sector;
    private LocalTime horaClases;

    public Usuario(int id, String nombre, String correo, String sector, LocalTime horaClases) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.sector = sector;
        this.horaClases = horaClases;
    }

    /** Verifica que un correo tenga el formato institucional (@udla.edu.ec). */
    public static boolean correoInstitucionalValido(String correo) {
        return correo != null && correo.matches("^[A-Za-z0-9._%+-]+@udla\\.edu\\.ec$");
    }

    public boolean validarCorreo() {
        return correoInstitucionalValido(correo);
    }

    public abstract String getRol();

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }
    public String getSector() { return sector; }
    public void setSector(String sector) { this.sector = sector; }
    public LocalTime getHoraClases() { return horaClases; }
    public void setHoraClases(LocalTime horaClases) { this.horaClases = horaClases; }

    @Override
    public String toString() {
        return String.format("[%d] %-10s | %-25s | %-28s | %-15s | clases: %s",
                id, getRol(), nombre, correo, sector, horaClases);
    }
}
