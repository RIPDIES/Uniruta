package uniruta.modelo;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
public class Ruta {
    private final String id;
    private final String sectorOrigen;
    private final String destino;
    private final double distanciaKm;
    private final LocalTime horaSalida;
    private final Conductor conductor;
    private final List<Emparejamiento> emparejamientos = new ArrayList<>();

    public Ruta(String id, String sectorOrigen, String destino, double distanciaKm,
                LocalTime horaSalida, Conductor conductor) {
        this.id = id;
        this.sectorOrigen = sectorOrigen;
        this.destino = destino;
        this.distanciaKm = distanciaKm;
        this.horaSalida = horaSalida;
        this.conductor = conductor;
    }

    /** Número de pasajeros con emparejamiento aceptado. */
    public int contarPasajeros() {
        int n = 0;
        for (Emparejamiento e : emparejamientos) {
            if (e.getEstado() == EstadoEmparejamiento.ACEPTADO) n++;
        }
        return n;
    }

    public boolean tieneCupo() {
        Vehiculo v = conductor.getVehiculo();
        return v != null && contarPasajeros() < v.getPuestos();
    }

    public boolean estaCompleta() { return !tieneCupo(); }

    public void agregarEmparejamiento(Emparejamiento e) { emparejamientos.add(e); }
    public void quitarEmparejamiento(Emparejamiento e) { emparejamientos.remove(e); }
    public List<Emparejamiento> getEmparejamientos() { return new ArrayList<>(emparejamientos); }

    public String getId() { return id; }
    public String getSectorOrigen() { return sectorOrigen; }
    public String getDestino() { return destino; }
    public double getDistanciaKm() { return distanciaKm; }
    public LocalTime getHoraSalida() { return horaSalida; }
    public Conductor getConductor() { return conductor; }

    @Override
    public String toString() {
        Vehiculo v = conductor.getVehiculo();
        int puestos = v == null ? 0 : v.getPuestos();
        return String.format("%s | %s -> %s | %.1f km | salida %s | %s | pasajeros %d/%d%s",
                id, sectorOrigen, destino, distanciaKm, horaSalida, conductor.getNombre(),
                contarPasajeros(), puestos, estaCompleta() ? " | CUPO COMPLETO" : "");
    }
}
