package uniruta.modelo;

public class Vehiculo {
    private final String placa;
    private String modelo;
    private int puestos;
    private double rendimientoGalon;

    public Vehiculo(String placa, String modelo, int puestos, double rendimientoGalon) {
        this.placa = placa;
        this.modelo = modelo;
        this.puestos = puestos;
        this.rendimientoGalon = rendimientoGalon;
    }
    public static boolean placaValida(String placa) {
        return placa != null && placa.matches("^[A-Z]{3}-\\d{3,4}$");
    }
    public boolean validarPlaca() { return placaValida(placa); }
    public String getPlaca() { return placa; }
    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }
    public int getPuestos() { return puestos; }
    public void setPuestos(int puestos) { this.puestos = puestos; }
    public double getRendimientoGalon() { return rendimientoGalon; }
    public void setRendimientoGalon(double r) { this.rendimientoGalon = r; }
    @Override
    public String toString() {
        return String.format("%s | %s | %d puestos | %.1f km/gal", placa, modelo, puestos, rendimientoGalon);
    }
}
