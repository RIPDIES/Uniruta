package uniruta.modelo;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
public class Pasajero extends Usuario {
    private final List<Emparejamiento> emparejamientos = new ArrayList<>();

    public Pasajero(int id, String nombre, String correo, String sector, LocalTime horaClases) {
        super(id, nombre, correo, sector, horaClases);
    }
    public void agregarEmparejamiento(Emparejamiento e) { emparejamientos.add(e); }
    public void quitarEmparejamiento(Emparejamiento e) { emparejamientos.remove(e); }
    public List<Emparejamiento> getEmparejamientos() { return new ArrayList<>(emparejamientos); }
    @Override
    public String getRol() { return "Pasajero"; }
}
