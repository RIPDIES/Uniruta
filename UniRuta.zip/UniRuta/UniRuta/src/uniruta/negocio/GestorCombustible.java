package uniruta.negocio;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import uniruta.modelo.Combustible;
public class GestorCombustible {
    private final Map<String, Combustible> combustibles = new LinkedHashMap<>();
    private Combustible vigente;
    public Combustible registrar(String tipo, double precioGalon) throws ReglaNegocioException {
        if (tipo == null || tipo.isBlank()) throw new ReglaNegocioException("El tipo de combustible es obligatorio.");
        if (precioGalon <= 0 || precioGalon > 10) {
            throw new ReglaNegocioException("El precio por galón debe ser mayor a 0 y máximo $10.");
        }
        String clave = tipo.trim().toLowerCase();
        Combustible c = combustibles.get(clave);
        if (c == null) {
            c = new Combustible(tipo.trim(), precioGalon);
            combustibles.put(clave, c);
        } else {
            c.setPrecioGalon(precioGalon);
        }
        vigente = c;
        return c;
    }

    public void seleccionarVigente(String tipo) throws ReglaNegocioException {
        Combustible c = tipo == null ? null : combustibles.get(tipo.trim().toLowerCase());
        if (c == null) throw new ReglaNegocioException("No existe el combustible '" + tipo + "'.");
        vigente = c;
    }

    public Combustible getVigente() { return vigente; }

    public List<Combustible> listar() { return new ArrayList<>(combustibles.values()); }
}
