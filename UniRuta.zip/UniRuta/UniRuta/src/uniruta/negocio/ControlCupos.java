package uniruta.negocio;

import uniruta.modelo.Ruta;
import uniruta.modelo.Vehiculo;
public class ControlCupos {

    public void verificarCupo(Ruta ruta) throws ReglaNegocioException {
        if (ruta.getConductor().getVehiculo() == null) {
            throw new ReglaNegocioException("El conductor de la ruta " + ruta.getId() + " no tiene vehículo.");
        }
        if (ruta.estaCompleta()) {
            throw new ReglaNegocioException("La ruta " + ruta.getId() + " está en estado 'Cupo Completo' ("
                    + ruta.contarPasajeros() + "/" + ruta.getConductor().getVehiculo().getPuestos() + ").");
        }
    }

    public String estado(Ruta ruta) {
        Vehiculo v = ruta.getConductor().getVehiculo();
        int puestos = v == null ? 0 : v.getPuestos();
        return ruta.estaCompleta()
                ? "Cupo Completo (" + ruta.contarPasajeros() + "/" + puestos + ")"
                : "Disponible (" + ruta.contarPasajeros() + "/" + puestos + ")";
    }
}
