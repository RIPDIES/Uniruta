package uniruta.negocio;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
public class CatalogoSectores {
    public static final String CAMPUS = "Campus Granados";

    private final Map<String, double[]> coordenadas = new LinkedHashMap<>();
    private final Map<String, String> nombres = new LinkedHashMap<>();

    public CatalogoSectores() {
        agregar(CAMPUS, 1.5, 5.5);
        agregar("Centro Histórico", 0, 0);
        agregar("La Mariscal", 0.5, 2);
        agregar("La Floresta", 1.5, 2);
        agregar("Guápulo", 2.5, 2.3);
        agregar("La Carolina", 0.5, 4);
        agregar("Iñaquito", 0.5, 4.5);
        agregar("El Batán", 1.5, 5);
        agregar("Kennedy", 0, 6.5);
        agregar("Cotocollao", -1.5, 9);
        agregar("El Condado", -3, 9.5);
        agregar("Ponceano", -1, 10.5);
        agregar("Carcelén", -0.5, 13);
        agregar("Calderón", 3, 14.5);
        agregar("Pomasqui", -1, 19);
        agregar("Chimbacalle", -0.5, -2.5);
        agregar("La Magdalena", -1, -5);
        agregar("Solanda", -1.5, -8);
        agregar("Quitumbe", -2, -14);
        agregar("Cumbayá", 11, 4);
        agregar("Tumbaco", 17, 3);
        agregar("Conocoto", 11, -8);
        agregar("San Rafael", 13, -6);
        agregar("Sangolquí", 17, -8);
    }

    private void agregar(String nombre, double x, double y) {
        String clave = normalizar(nombre);
        coordenadas.put(clave, new double[]{x, y});
        nombres.put(clave, nombre);
    }

    private static String normalizar(String s) {
        String n = Normalizer.normalize(s.trim(), Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return n.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }

    public boolean existe(String sector) {
        return sector != null && coordenadas.containsKey(normalizar(sector));
    }
    public String nombreOficial(String sector) {
        return sector == null ? null : nombres.get(normalizar(sector));
    }

    public boolean esCampus(String sector) {
        return existe(sector) && normalizar(sector).equals(normalizar(CAMPUS));
    }

    public List<String> listarSectores() {
        List<String> lista = new ArrayList<>(nombres.values());
        Collections.sort(lista);
        return lista;
    }

    private double[] coord(String sector) {
        return coordenadas.get(normalizar(sector));
    }
    public double distancia(String a, String b) {
        double[] p = coord(a);
        double[] q = coord(b);
        return Math.hypot(p[0] - q[0], p[1] - q[1]);
    }
    public double desvioKm(String sectorPasajero, String origen, String destino) {
        double[] p = coord(sectorPasajero);
        double[] a = coord(origen);
        double[] b = coord(destino);
        double dx = b[0] - a[0];
        double dy = b[1] - a[1];
        double largo2 = dx * dx + dy * dy;
        double t = largo2 == 0 ? 0 : ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / largo2;
        t = Math.max(0, Math.min(1, t));
        return Math.hypot(p[0] - (a[0] + t * dx), p[1] - (a[1] + t * dy));
    }
}
