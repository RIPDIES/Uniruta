package uniruta.negocio;

import java.time.Duration;
import java.time.LocalTime;
public class ValidadorHorario {
    public static final long TOLERANCIA_MINUTOS = 45;

    public void validar(LocalTime salidaConductor, LocalTime entradaPasajero) throws ReglaNegocioException {
        if (salidaConductor == null || entradaPasajero == null) {
            throw new ReglaNegocioException("Las horas de salida y de entrada son obligatorias.");
        }
        long diferencia = Duration.between(salidaConductor, entradaPasajero).toMinutes();
        if (diferencia < 0) {
            throw new ReglaNegocioException("Incompatibilidad de horario: el conductor sale (" + salidaConductor
                    + ") después de la entrada a clases del pasajero (" + entradaPasajero + ").");
        }
        if (diferencia > TOLERANCIA_MINUTOS) {
            throw new ReglaNegocioException("Incompatibilidad de horario: el conductor sale " + diferencia
                    + " minutos antes de la entrada del pasajero (máximo " + TOLERANCIA_MINUTOS + ").");
        }
    }

    public boolean sonCompatibles(LocalTime salidaConductor, LocalTime entradaPasajero) {
        try {
            validar(salidaConductor, entradaPasajero);
            return true;
        } catch (ReglaNegocioException e) {
            return false;
        }
    }
}
