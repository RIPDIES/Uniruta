package uniruta.negocio;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import uniruta.modelo.Conductor;
import uniruta.modelo.Emparejamiento;
import uniruta.modelo.Ruta;
public class GestorRutas {
    private final Map<String, Ruta> rutas = new LinkedHashMap<>();
    private final CatalogoSectores catalogo;
    private int siguiente = 1;

    public GestorRutas(CatalogoSectores catalogo) {
        this.catalogo = catalogo;
    }
    public Ruta registrar(Conductor conductor, String origen, String destino, LocalTime horaSalida, double distanciaKm)
            throws ReglaNegocioException {
        if (conductor == null) throw new ReglaNegocioException("Debe indicar un conductor.");
        if (conductor.getVehiculo() == null) {
            throw new ReglaNegocioException("El conductor debe registrar un vehículo antes de publicar rutas.");
        }
        if (!catalogo.existe(origen)) {
            throw new ReglaNegocioException("El sector de origen '" + origen + "' no existe en el catálogo.");
        }
        if (catalogo.esCampus(origen)) {
            throw new ReglaNegocioException("El origen no puede ser el campus universitario.");
        }
        if (!catalogo.esCampus(destino)) {
            throw new ReglaNegocioException("El destino debe ser el campus universitario (" + CatalogoSectores.CAMPUS + ").");
        }
        if (horaSalida == null) throw new ReglaNegocioException("La hora de salida es obligatoria.");
        if (distanciaKm <= 0 || distanciaKm > 100) {
            throw new ReglaNegocioException("La distancia debe ser mayor a 0 y máximo 100 km.");
        }
        String id = String.format("R%03d", siguiente++);
        Ruta r = new Ruta(id, catalogo.nombreOficial(origen), catalogo.nombreOficial(destino),
                distanciaKm, horaSalida, conductor);
        rutas.put(id, r);
        conductor.agregarRuta(r);
        return r;
    }

    public Ruta buscar(String id) {
        return id == null ? null : rutas.get(id.trim().toUpperCase());
    }

    public List<Ruta> listar() {
        return new ArrayList<>(rutas.values());
    }

    public List<Ruta> porConductor(Conductor c) {
        return c.getRutas();
    }

    public void eliminar(String id) throws ReglaNegocioException {
        Ruta r = buscar(id);
        if (r == null) throw new ReglaNegocioException("No existe la ruta " + id + ".");
        for (Emparejamiento e : r.getEmparejamientos()) {
            e.getPasajero().quitarEmparejamiento(e);
        }
        r.getConductor().quitarRuta(r);
        rutas.remove(r.getId());
    }
}
