package uniruta.negocio;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import uniruta.modelo.Combustible;
import uniruta.modelo.Emparejamiento;
import uniruta.modelo.EstadoEmparejamiento;
import uniruta.modelo.Pasajero;
import uniruta.modelo.Ruta;
public class CalculadorCostos {
    public static class Liquidacion {
        private final LocalDate fecha;
        private final Pasajero pasajero;
        private final String rutaId;
        private final double costoTotal;
        private final double cuota;

        public Liquidacion(LocalDate fecha, Pasajero pasajero, String rutaId, double costoTotal, double cuota) {
            this.fecha = fecha;
            this.pasajero = pasajero;
            this.rutaId = rutaId;
            this.costoTotal = costoTotal;
            this.cuota = cuota;
        }

        public LocalDate getFecha() { return fecha; }
        public Pasajero getPasajero() { return pasajero; }
        public String getRutaId() { return rutaId; }
        public double getCostoTotal() { return costoTotal; }
        public double getCuota() { return cuota; }
        public double getAhorro() { return costoTotal - cuota; }
    }

    private final GestorCombustible combustibles;
    private final List<Liquidacion> historial = new ArrayList<>();

    public CalculadorCostos(GestorCombustible combustibles) {
        this.combustibles = combustibles;
    }

    public static double costoTotal(double distanciaKm, double rendimiento, double precio) throws ReglaNegocioException {
        if (distanciaKm <= 0) throw new ReglaNegocioException("La distancia debe ser mayor a 0.");
        if (rendimiento <= 0) throw new ReglaNegocioException("El rendimiento debe ser mayor a 0.");
        if (precio <= 0) throw new ReglaNegocioException("El precio del combustible debe ser mayor a 0.");
        return (distanciaKm / rendimiento) * precio;
    }
    public double calcularCuota(double distanciaKm, double rendimiento, double precio, int pasajeros)
            throws ReglaNegocioException {
        if (pasajeros < 1) throw new ReglaNegocioException("Debe haber al menos 1 pasajero.");
        return costoTotal(distanciaKm, rendimiento, precio) / (pasajeros + 1);
    }

    private Combustible exigirCombustible() throws ReglaNegocioException {
        Combustible c = combustibles.getVigente();
        if (c == null) throw new ReglaNegocioException("Primero registre el precio del combustible (RF07).");
        return c;
    }

    private static void exigirPasajeros(Ruta ruta) throws ReglaNegocioException {
        if (ruta.contarPasajeros() < 1) {
            throw new ReglaNegocioException("La ruta " + ruta.getId() + " no tiene pasajeros aceptados.");
        }
    }

    public double costoTotalRuta(Ruta ruta) throws ReglaNegocioException {
        Combustible c = exigirCombustible();
        return costoTotal(ruta.getDistanciaKm(), ruta.getConductor().getVehiculo().getRendimientoGalon(),
                c.getPrecioGalon());
    }

    public double cuotaRuta(Ruta ruta) throws ReglaNegocioException {
        exigirPasajeros(ruta);
        return costoTotalRuta(ruta) / (ruta.contarPasajeros() + 1);
    }
    public void actualizarCuotas(Ruta ruta) {
        try {
            double cuota = cuotaRuta(ruta);
            for (Emparejamiento e : ruta.getEmparejamientos()) {
                if (e.getEstado() == EstadoEmparejamiento.ACEPTADO) e.setCuota(cuota);
            }
        } catch (ReglaNegocioException ex) {
        }
    }
    public List<Liquidacion> registrarViaje(Ruta ruta, LocalDate fecha) throws ReglaNegocioException {
        if (fecha == null) throw new ReglaNegocioException("La fecha es obligatoria.");
        exigirPasajeros(ruta);
        for (Liquidacion l : historial) {
            if (l.getRutaId().equals(ruta.getId()) && l.getFecha().equals(fecha)) {
                throw new ReglaNegocioException("El viaje de la ruta " + ruta.getId() + " ya fue registrado el " + fecha + ".");
            }
        }
        double total = costoTotalRuta(ruta);
        double cuota = total / (ruta.contarPasajeros() + 1);
        List<Liquidacion> nuevas = new ArrayList<>();
        for (Emparejamiento e : ruta.getEmparejamientos()) {
            if (e.getEstado() == EstadoEmparejamiento.ACEPTADO) {
                nuevas.add(new Liquidacion(fecha, e.getPasajero(), ruta.getId(), total, cuota));
            }
        }
        historial.addAll(nuevas);
        return nuevas;
    }

    public List<Liquidacion> liquidaciones(YearMonth mes) {
        List<Liquidacion> lista = new ArrayList<>();
        for (Liquidacion l : historial) {
            if (YearMonth.from(l.getFecha()).equals(mes)) lista.add(l);
        }
        return lista;
    }
    public Map<Pasajero, double[]> reporteMensual(YearMonth mes) {
        Map<Pasajero, double[]> reporte = new LinkedHashMap<>();
        for (Liquidacion l : liquidaciones(mes)) {
            double[] fila = reporte.computeIfAbsent(l.getPasajero(), k -> new double[3]);
            fila[0] += 1;
            fila[1] += l.getCuota();
            fila[2] += l.getAhorro();
        }
        return reporte;
    }
}
