package uniruta.negocio;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import uniruta.modelo.Conductor;
import uniruta.modelo.Ruta;
import uniruta.modelo.Vehiculo;
public class GestorVehiculos {
    private final Map<String, Vehiculo> vehiculos = new LinkedHashMap<>();
    private final Map<String, Conductor> duenos = new LinkedHashMap<>();
    public String validarPlaca(String placa) throws ReglaNegocioException {
        if (placa == null || placa.isBlank()) throw new ReglaNegocioException("La placa es obligatoria.");
        String p = placa.trim().toUpperCase().replaceAll("^([A-Z]{3})(\\d{3,4})$", "$1-$2");
        if (!Vehiculo.placaValida(p)) {
            throw new ReglaNegocioException("Placa inválida. Formato esperado: ABC-1234.");
        }
        if (vehiculos.containsKey(p)) throw new ReglaNegocioException("La placa " + p + " ya está registrada.");
        return p;
    }
    public Vehiculo registrar(Conductor conductor, String placa, String modelo, int puestos, double rendimiento)
            throws ReglaNegocioException {
        if (conductor == null) throw new ReglaNegocioException("Debe indicar un conductor.");
        if (conductor.getVehiculo() != null) {
            throw new ReglaNegocioException("El conductor ya tiene un vehículo registrado.");
        }
        String p = validarPlaca(placa);
        if (modelo == null || modelo.isBlank()) throw new ReglaNegocioException("El modelo es obligatorio.");
        if (puestos < 1 || puestos > 8) {
            throw new ReglaNegocioException("Los puestos para pasajeros deben estar entre 1 y 8.");
        }
        if (rendimiento <= 0 || rendimiento > 200) {
            throw new ReglaNegocioException("El rendimiento debe ser mayor a 0 y máximo 200 km por galón.");
        }
        Vehiculo v = new Vehiculo(p, modelo.trim(), puestos, rendimiento);
        vehiculos.put(p, v);
        duenos.put(p, conductor);
        conductor.asignarVehiculo(v);
        return v;
    }

    public Vehiculo buscarPorPlaca(String placa) {
        return placa == null ? null : vehiculos.get(placa.trim().toUpperCase());
    }

    public List<Vehiculo> listar() {
        return new ArrayList<>(vehiculos.values());
    }

    public Conductor duenoDe(String placa) {
        return duenos.get(placa.trim().toUpperCase());
    }

    public void actualizar(String placa, int puestos, double rendimiento) throws ReglaNegocioException {
        Vehiculo v = buscarPorPlaca(placa);
        if (v == null) throw new ReglaNegocioException("No existe un vehículo con placa " + placa + ".");
        if (puestos < 1 || puestos > 8) {
            throw new ReglaNegocioException("Los puestos para pasajeros deben estar entre 1 y 8.");
        }
        if (rendimiento <= 0 || rendimiento > 200) {
            throw new ReglaNegocioException("El rendimiento debe ser mayor a 0 y máximo 200 km por galón.");
        }
        for (Ruta r : duenos.get(v.getPlaca()).getRutas()) {
            if (r.contarPasajeros() > puestos) {
                throw new ReglaNegocioException("No se pueden reducir los puestos a " + puestos + ": la ruta "
                        + r.getId() + " ya tiene " + r.contarPasajeros() + " pasajeros.");
            }
        }
        v.setPuestos(puestos);
        v.setRendimientoGalon(rendimiento);
    }

    public void eliminar(String placa) throws ReglaNegocioException {
        Vehiculo v = buscarPorPlaca(placa);
        if (v == null) throw new ReglaNegocioException("No existe un vehículo con placa " + placa + ".");
        Conductor c = duenos.get(v.getPlaca());
        if (!c.getRutas().isEmpty()) {
            throw new ReglaNegocioException("Elimine primero las rutas del conductor.");
        }
        c.asignarVehiculo(null);
        vehiculos.remove(v.getPlaca());
        duenos.remove(v.getPlaca());
    }
}
