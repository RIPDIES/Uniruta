package uniruta.negocio;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import uniruta.modelo.Conductor;
import uniruta.modelo.Emparejamiento;
import uniruta.modelo.EstadoEmparejamiento;
import uniruta.modelo.Pasajero;
import uniruta.modelo.Usuario;
public class GestorUsuarios {
    private final Map<Integer, Usuario> usuarios = new LinkedHashMap<>();
    private final CatalogoSectores catalogo;
    private int siguienteId = 1;

    public GestorUsuarios(CatalogoSectores catalogo) {
        this.catalogo = catalogo;
    }

    public void validarNombre(String nombre) throws ReglaNegocioException {
        if (nombre == null || !nombre.trim().matches("^[\\p{L}][\\p{L} .'-]{2,59}$")) {
            throw new ReglaNegocioException(
                    "El nombre es obligatorio (3 a 60 caracteres, solo letras y espacios).");
        }
    }

    public void validarSector(String sector) throws ReglaNegocioException {
        if (!catalogo.existe(sector)) {
            throw new ReglaNegocioException("El sector '" + sector
                    + "' no existe en el catálogo. Consulte la lista de sectores disponibles.");
        }
    }
    public String validarCorreoNuevo(String correo) throws ReglaNegocioException {
        if (correo == null || !Usuario.correoInstitucionalValido(correo.trim().toLowerCase())) {
            throw new ReglaNegocioException("Debe ingresar un correo institucional válido (@udla.edu.ec)");
        }
        String c = correo.trim().toLowerCase();
        if (buscarPorCorreo(c) != null) {
            throw new ReglaNegocioException("Ya existe un usuario registrado con el correo " + c + ".");
        }
        return c;
    }
    public Usuario registrar(String nombre, String correo, String sector, String rol, LocalTime horaClases)
            throws ReglaNegocioException {
        validarNombre(nombre);
        correo = validarCorreoNuevo(correo);
        validarSector(sector);
        if (horaClases == null) {
            throw new ReglaNegocioException("La hora habitual de entrada a clases es obligatoria.");
        }
        if (rol == null) {
            throw new ReglaNegocioException("El rol es obligatorio (Conductor o Pasajero).");
        }
        String sectorOficial = catalogo.nombreOficial(sector);
        Usuario u;
        if (rol.trim().equalsIgnoreCase("Conductor")) {
            u = new Conductor(siguienteId, nombre.trim(), correo, sectorOficial, horaClases);
        } else if (rol.trim().equalsIgnoreCase("Pasajero")) {
            u = new Pasajero(siguienteId, nombre.trim(), correo, sectorOficial, horaClases);
        } else {
            throw new ReglaNegocioException("El rol debe ser Conductor o Pasajero.");
        }
        usuarios.put(siguienteId, u);
        siguienteId++;
        return u;
    }

    public Usuario buscarPorId(int id) {
        return usuarios.get(id);
    }

    public Usuario buscarPorCorreo(String correo) {
        for (Usuario u : usuarios.values()) {
            if (u.getCorreo().equalsIgnoreCase(correo.trim())) return u;
        }
        return null;
    }

    public Conductor obtenerConductor(int id) throws ReglaNegocioException {
        Usuario u = usuarios.get(id);
        if (u == null) throw new ReglaNegocioException("No existe un usuario con ID " + id + ".");
        if (!(u instanceof Conductor)) throw new ReglaNegocioException("El usuario " + id + " no es Conductor.");
        return (Conductor) u;
    }

    public Pasajero obtenerPasajero(int id) throws ReglaNegocioException {
        Usuario u = usuarios.get(id);
        if (u == null) throw new ReglaNegocioException("No existe un usuario con ID " + id + ".");
        if (!(u instanceof Pasajero)) throw new ReglaNegocioException("El usuario " + id + " no es Pasajero.");
        return (Pasajero) u;
    }

    public List<Usuario> listar() {
        return new ArrayList<>(usuarios.values());
    }

    public void actualizar(int id, String nombre, String sector, LocalTime horaClases) throws ReglaNegocioException {
        Usuario u = usuarios.get(id);
        if (u == null) throw new ReglaNegocioException("No existe un usuario con ID " + id + ".");
        validarNombre(nombre);
        validarSector(sector);
        if (horaClases == null) throw new ReglaNegocioException("La hora de clases es obligatoria.");
        u.setNombre(nombre.trim());
        u.setSector(catalogo.nombreOficial(sector));
        u.setHoraClases(horaClases);
    }

    public void eliminar(int id) throws ReglaNegocioException {
        Usuario u = usuarios.get(id);
        if (u == null) throw new ReglaNegocioException("No existe un usuario con ID " + id + ".");
        if (u instanceof Conductor) {
            Conductor c = (Conductor) u;
            if (c.getVehiculo() != null || !c.getRutas().isEmpty()) {
                throw new ReglaNegocioException("Elimine primero el vehículo y las rutas del conductor.");
            }
        } else {
            for (Emparejamiento e : ((Pasajero) u).getEmparejamientos()) {
                if (e.getEstado() == EstadoEmparejamiento.ACEPTADO) {
                    throw new ReglaNegocioException("El pasajero tiene emparejamientos activos; cancélelos o elimine la ruta primero.");
                }
            }
        }
        usuarios.remove(id);
    }
}
