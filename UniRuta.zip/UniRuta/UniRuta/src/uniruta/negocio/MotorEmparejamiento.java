package uniruta.negocio;

import java.util.ArrayList;
import java.util.List;
import uniruta.modelo.Emparejamiento;
import uniruta.modelo.EstadoEmparejamiento;
import uniruta.modelo.Pasajero;
import uniruta.modelo.Ruta;
public class MotorEmparejamiento {
    public static final double DESVIO_MAXIMO_KM = 4.0;

    private final ValidadorHorario validadorHorario;
    private final ControlCupos controlCupos;
    private final CatalogoSectores catalogo;

    public MotorEmparejamiento(ValidadorHorario validadorHorario, ControlCupos controlCupos, CatalogoSectores catalogo) {
        this.validadorHorario = validadorHorario;
        this.controlCupos = controlCupos;
        this.catalogo = catalogo;
    }

    public double calcularDesvio(Pasajero pasajero, Ruta ruta) {
        return catalogo.desvioKm(pasajero.getSector(), ruta.getSectorOrigen(), ruta.getDestino());
    }
    public String evaluar(Pasajero pasajero, Ruta ruta) {
        for (Emparejamiento e : pasajero.getEmparejamientos()) {
            if (e.getRuta() == ruta && e.getEstado() == EstadoEmparejamiento.ACEPTADO) {
                return "El pasajero ya está inscrito en la ruta " + ruta.getId() + ".";
            }
        }
        try {
            controlCupos.verificarCupo(ruta);
            validadorHorario.validar(ruta.getHoraSalida(), pasajero.getHoraClases());
        } catch (ReglaNegocioException ex) {
            return ex.getMessage();
        }
        double desvio = calcularDesvio(pasajero, ruta);
        if (desvio > DESVIO_MAXIMO_KM) {
            return String.format("Match rechazado por ineficiencia de recorrido: el desvío estimado es %.1f km "
                    + "y el máximo permitido es %.1f km.", desvio, DESVIO_MAXIMO_KM);
        }
        return null;
    }
    public Emparejamiento emparejar(Pasajero pasajero, Ruta ruta) throws ReglaNegocioException {
        String motivo = evaluar(pasajero, ruta);
        if (motivo != null) throw new ReglaNegocioException(motivo);
        Emparejamiento e = new Emparejamiento(pasajero, ruta, calcularDesvio(pasajero, ruta));
        e.aceptar();
        ruta.agregarEmparejamiento(e);
        pasajero.agregarEmparejamiento(e);
        return e;
    }
    public List<Ruta> buscarCompatibles(Pasajero pasajero, List<Ruta> rutas) {
        List<Ruta> compatibles = new ArrayList<>();
        for (Ruta r : rutas) {
            if (evaluar(pasajero, r) == null) compatibles.add(r);
        }
        return compatibles;
    }
}
